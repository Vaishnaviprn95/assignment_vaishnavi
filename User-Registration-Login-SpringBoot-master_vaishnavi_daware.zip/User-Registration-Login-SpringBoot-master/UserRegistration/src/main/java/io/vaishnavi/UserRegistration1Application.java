package io.vaishnavi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegistration1Application 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(UserRegistration1Application.class, args);
	}
	
}
